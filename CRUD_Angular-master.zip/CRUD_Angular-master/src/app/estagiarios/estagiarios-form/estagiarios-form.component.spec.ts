import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EstagiariosFormComponent } from './estagiarios-form.component';

describe('CursosFormComponent', () => {
  let component: EstagiariosFormComponent;
  let fixture: ComponentFixture<EstagiariosFormComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EstagiariosFormComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EstagiariosFormComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
