import { Estagiario } from './../Estagiario';
import { ActivatedRoute } from '@angular/router';
import { EstagiariosService } from './../../estagiarios.service';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Location } from '@angular/common';

@Component({
  selector: 'app-estagiarios-form',
  templateUrl: './estagiarios-form.component.html',
  styleUrls: ['./estagiarios-form.component.scss']
})
export class EstagiariosFormComponent implements OnInit {

  form!: FormGroup;
  submitted = false;

  constructor(private formBuilder: FormBuilder, private service: EstagiariosService, private location:
    Location, private route: ActivatedRoute) { }

  ngOnInit(): void {

    const estagiario = this.route.snapshot.data.estagiario;

    this.form = this.formBuilder.group({
      id: [estagiario.id],
      nome: [estagiario.nome, [Validators.required, Validators.minLength(3), Validators.maxLength(250)]],
      idade: [estagiario.idade, [Validators.required, Validators.minLength(1), Validators.maxLength(3)]],
      email: [estagiario.email, [Validators.required]],
      telefone: [estagiario.telefone, [Validators.required]],
      cpf: [estagiario.cpf, [Validators.required]],
      sexo: [estagiario.sexo, [Validators.required]],
      data: [estagiario.data, [Validators.required]]
    });
  }

  // tslint:disable-next-line: typedef
  onSubmit() {
    this.submitted = true;
    console.log(this.form.value);

    if (this.form.valid) {
      console.log('submitted');

      let msgSucesso = 'Estagiário criado com sucesso!';
      let msgError = 'Erro ao criar estagiário, tente novamente!';

      if (this.form.value.id) {
        msgSucesso = 'Estagiário atualizado com sucesso!';
        msgError = 'Erro ao criar atualizado, tente novamente!';
      }

      this.service.save(this.form.value).subscribe(
        sucess => {
          alert(msgSucesso);
          this.location.back();
        },
        error => {
          alert(msgError);
        }
      );
    }
  }

  // tslint:disable-next-line: typedef
  onCancel() {
    this.submitted = false;
    this.form.reset();
  }

  // tslint:disable-next-line: typedef
  hasError(field: string) {
    return this.form.get(field)?.errors;
  }
}
