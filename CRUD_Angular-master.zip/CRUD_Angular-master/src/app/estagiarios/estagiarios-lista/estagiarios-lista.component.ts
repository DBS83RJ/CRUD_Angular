import { ActivatedRoute, Router } from '@angular/router';
import { Estagiario } from './../Estagiario';
import { EstagiariosService } from './../../estagiarios.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { EmptyError, Observable, Subject } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { BsModalRef } from 'ngx-bootstrap/modal';

@Component({
  selector: 'app-estagiarios-lista',
  templateUrl: './estagiarios-lista.component.html',
  styleUrls: ['./estagiarios-lista.component.scss'],
  preserveWhitespaces: true
})
export class EstagiariosListaComponent implements OnInit {

  deleteModalRef!: BsModalRef;
  @ViewChild('deleteModal') deleteModal: any;

  estagiarios$!: Observable<Estagiario[]>;
  error$ = new Subject<boolean>();

  constructor(private service: EstagiariosService, private router: Router, private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.onRefresh();
  }

  onRefresh(): void {
    this.estagiarios$ = this.service.list().
      pipe(
        catchError(error => {
          this.error$.next(true);
          return EmptyError;
        })
      );
  }

  // tslint:disable-next-line: typedef
  onEdit(id: number) {
    this.router.navigate(['editar', id], { relativeTo: this.route });
  }

  // tslint:disable-next-line: typedef
  onDelete(id: number){
    this.service.delete(id).subscribe(
      (sucess) => {
        alert('Estagiário excluido com sucesso!!');
        window.location.reload();
      },
      (error) => {
        alert('Atenção. Erro ao Excluir estagiário!');
      }
    );
  }

}

