import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EstagiariosListaComponent } from './estagiarios-lista.component';

describe('EstagiariosListaComponent', () => {
  let component: EstagiariosListaComponent;
  let fixture: ComponentFixture<EstagiariosListaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EstagiariosListaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EstagiariosListaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
