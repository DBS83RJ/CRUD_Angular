import { EstagiarioResolverGuard } from './guards/estagiario-resolver.guard';
import { EstagiariosListaComponent } from './estagiarios-lista/estagiarios-lista.component';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EstagiariosFormComponent } from './estagiarios-form/estagiarios-form.component';

const routes: Routes = [
  {path: '', component: EstagiariosListaComponent},
  {path: 'novo', component: EstagiariosFormComponent},
  {path: 'editar/:id', component: EstagiariosFormComponent, resolve: {
    estagiario: EstagiarioResolverGuard
  }}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EstagiariosRoutingModule { }
