export interface Estagiario{
   id: number;
   nome: string;
   idade: number;
   email: string;
   telefone: string;
   sexo: string;
   cpf: string;
   data: Date;
}
