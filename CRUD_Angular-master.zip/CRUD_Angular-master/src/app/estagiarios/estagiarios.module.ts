import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EstagiariosRoutingModule } from './estagiarios-routing.module';
import { EstagiariosListaComponent } from './estagiarios-lista/estagiarios-lista.component';
import { ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    EstagiariosListaComponent
  ],
  imports: [
    CommonModule,
    EstagiariosRoutingModule,
    ReactiveFormsModule
  ]
})
export class EstagiariosModule { }
