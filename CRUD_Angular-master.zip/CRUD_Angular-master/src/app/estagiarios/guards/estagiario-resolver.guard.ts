import { Estagiario } from './../Estagiario';
import { EstagiariosService } from './../../estagiarios.service';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Resolve, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable, of } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class EstagiarioResolverGuard implements Resolve<Estagiario> {

  constructor(private service: EstagiariosService){}

  resolve(route: ActivatedRouteSnapshot, state: RouterStateSnapshot): Estagiario | Observable<Estagiario> | Promise<Estagiario> {

    if (route.params && route.params.id){
      return this.service.loadById(route.params.id);
    }

    // tslint:disable-next-line: deprecation
    return of ();
  }
}


