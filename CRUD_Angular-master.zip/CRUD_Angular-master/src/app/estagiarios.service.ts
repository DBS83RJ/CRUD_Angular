import { environment } from './../environments/environment';
import { Estagiario } from './estagiarios/Estagiario';
import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { delay, take, tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class EstagiariosService {

  constructor(private http: HttpClient) { }

  private readonly API = `${environment.API}estagiarios`;

  // tslint:disable-next-line: typedef
  list() {
    return this.http.get<Estagiario[]>(this.API)
      .pipe(
        delay(2000),
        tap(console.log)
      );
  }

  // tslint:disable-next-line: typedef
  private create(estagiario: Estagiario) {
    return this.http.post(this.API, estagiario).pipe(take(1));
  }

  // tslint:disable-next-line: typedef
  loadById(id: number) {
    return this.http.get<Estagiario>(`${this.API}/${id}`).pipe(take(1));
  }

  // tslint:disable-next-line: typedef
  private update(estagiario: Estagiario) {
    return this.http.put(`${this.API}/${estagiario.id}`, estagiario).pipe(take(1));
  }

  // tslint:disable-next-line: typedef
  save(estagiario: Estagiario) {
    if (estagiario.id) {
      return this.update(estagiario);
    }
    return this.create(estagiario);
  }

  // tslint:disable-next-line: typedef
  delete(id: number){
    return this.http.delete(`${this.API}/${id}`).pipe(take(1));
  }
}
