import { TestBed } from '@angular/core/testing';

import { EstagiarioResolverGuard } from './estagiarios/guards/estagiario-resolver.guard';

describe('EstagiarioResolverGuard', () => {
  let guard: EstagiarioResolverGuard;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    guard = TestBed.inject(EstagiarioResolverGuard);
  });

  it('should be created', () => {
    expect(guard).toBeTruthy();
  });
});
