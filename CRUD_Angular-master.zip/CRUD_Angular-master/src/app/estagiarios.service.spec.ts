import { TestBed } from '@angular/core/testing';

import { EstagiariosService } from './estagiarios.service';

describe('EstagiariosService', () => {
  let service: EstagiariosService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(EstagiariosService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
